package kr.ac.kopo.exchange.dao;

import java.util.List;

import kr.ac.kopo.exchange.vo.CurlistVO;
import kr.ac.kopo.exchange.vo.CurrencyVO;
import kr.ac.kopo.exchange.vo.ExchangeVO;
import kr.ac.kopo.exchange.vo.ReserveVO;

public interface ExchangeDAO {
	
	
	/**
	 * 모든 통화의 환율정보 리스트 제공
	 */
	public List<CurrencyVO> selectAll();
	
	
	/**
	 * 환전하기에서 통화 선택하면 현재환율정보 띄어주는 부분 ajax
	 * @param currency
	 * @return
	 */
	public CurrencyVO getRateCommission(String currency);
	
	
	/**
	 * 환전하기 기능
	 * @param exchangeVO
	 */
	public void doExchange(ExchangeVO exchangeVO);
	
	
	/**
	 * 환전예약하기
	 * @param reserveVO
	 */
	public void doReserve(ReserveVO reserveVO);
	
	
	
	/**
	 * 비회원 환전하기
	 * @param exchangeVO
	 */
	public void doKakaoExchange(ExchangeVO exchangeVO);
	
	
	/**
	 * 환전내역 id 기준으로 조회
	 * @param id
	 * @return
	 */
	public List<ExchangeVO> selectExchange(String id);
	
	
	
	
	/**
	 * 환전 예약 내역 id기준으로 조회
	 * @param id
	 * @return
	 */
	public List<ReserveVO> selectReserve(String id);
	
	
	/**
	 * 보유외화 조회
	 * @param accounnt_num
	 * @return
	 */
	public List<CurlistVO> selectCurrency(String accounnt_num);
	
	
	
	
	

}
